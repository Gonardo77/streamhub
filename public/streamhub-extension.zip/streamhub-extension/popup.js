chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
  const el = document.getElementById('status');
  if (response?.ok) {
    el.className = 'status ok';
    el.textContent = '✓ StreamHub Connector is active';
  } else {
    el.textContent = 'Extension loaded. Open StreamHub to connect your platforms.';
  }
});
