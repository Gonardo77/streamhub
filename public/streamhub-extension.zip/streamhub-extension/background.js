// ── StreamHub Connector - Background Service Worker ──

const PLATFORM_DOMAINS = {
  netflix: 'netflix.com',
  disney:  'disneyplus.com',
  amazon:  'primevideo.com',
  flow:    'flow.com.ar'
};

const STREAMHUB_URL = 'https://streamhub-production-0416.up.railway.app';

// Listen for messages from StreamHub web app
chrome.runtime.onMessageExternal.addListener(async (message, sender, sendResponse) => {
  if (message.action === 'getCookies') {
    const { platform, token } = message;
    const domain = PLATFORM_DOMAINS[platform];
    if (!domain) { sendResponse({ error: 'Unknown platform' }); return; }

    try {
      // Get all cookies for this platform
      const cookies = await chrome.cookies.getAll({ domain });
      if (cookies.length === 0) {
        sendResponse({ error: 'No cookies found. Please log in to the platform first.' });
        return;
      }

      // Send cookies to StreamHub server
      const resp = await fetch(`${STREAMHUB_URL}/api/credentials`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ platform, cookies })
      });

      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error);
      sendResponse({ ok: true });

    } catch (e) {
      sendResponse({ error: e.message });
    }
  }

  if (message.action === 'ping') {
    sendResponse({ ok: true, version: '1.0' });
  }

  return true; // keep channel open for async response
});

// Also handle internal messages (from popup)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ping') {
    sendResponse({ ok: true });
  }
  return true;
});
