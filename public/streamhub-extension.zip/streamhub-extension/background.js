// ── StreamHub Connector - Background Service Worker ──

const PLATFORM_DOMAINS = {
  netflix: ['netflix.com'],
  disney:  ['disneyplus.com'],
  amazon:  ['primevideo.com', 'amazon.com'],
  flow:    ['flow.com.ar']
};

const STREAMHUB_ORIGINS = [
  'https://streamhub-production-0416.up.railway.app',
  'http://localhost:3000'
];

// Listen for messages from StreamHub web app via externally_connectable
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!STREAMHUB_ORIGINS.includes(sender.origin)) {
    sendResponse({ error: 'Unauthorized origin' });
    return;
  }

  if (message.action === 'ping') {
    sendResponse({ ok: true, version: '1.0' });
    return true;
  }

  if (message.action === 'getCookies') {
    const { platform, token } = message;
    const domains = PLATFORM_DOMAINS[platform];
    if (!domains) { sendResponse({ error: 'Unknown platform' }); return; }

    // Gather cookies from all relevant domains
    Promise.all(domains.map(d => chrome.cookies.getAll({ domain: d })))
      .then(results => {
        const cookies = results.flat();
        if (cookies.length === 0) {
          sendResponse({ error: `No ${platform} cookies found. Make sure you are logged in.` });
          return;
        }

        // Send to StreamHub server
        fetch('https://streamhub-production-0416.up.railway.app/api/credentials', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ platform, cookies })
        })
        .then(r => r.json())
        .then(data => sendResponse({ ok: true, cookieCount: cookies.length }))
        .catch(e => sendResponse({ error: e.message }));
      })
      .catch(e => sendResponse({ error: e.message }));

    return true; // keep channel open
  }
});
